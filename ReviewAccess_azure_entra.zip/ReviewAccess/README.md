# BFC Access Review

Flask + SQLAlchemy app for quarterly access reviews: admins upload an
access-export spreadsheet, filter owners review and validate/deactivate
their users inline, delegate scoped review to a colleague, and admins
track completion, changes, and send reminders.

Built for deployment on **Microsoft Azure**, with **Microsoft Entra ID**
for sign-in and **Microsoft Graph** for reminder emails.

## Documentation

- **`SECURITY_ARCHITECTURE.md`** — architecture, auth, data protection,
  and open questions for security/architecture review.
- **`azure/README.md`** — step-by-step Azure deployment guide, plus
  `azure/main.bicep` (infrastructure-as-code).

## Local development

Local dev uses a sign-in bypass instead of a real Entra ID tenant, so you
don't need Azure access to work on the app.

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt

cp .env.example .env
# edit .env:
#   APP_ENV=development
#   SECRET_KEY=<any random string>
#   DEV_AUTH_BYPASS=true
#   BOOTSTRAP_ADMIN_UPNS=you@example.com
#   MAIL_ENABLED=false

python app.py
```

Visit `http://localhost:5000/login`, sign in as `you@example.com` (or
whichever address you put in `BOOTSTRAP_ADMIN_UPNS`) — you'll land in the
Admin panel. `DEV_AUTH_BYPASS` must never be `true` in a deployed
environment; the app refuses to start if it's on together with
`APP_ENV=production`.

## Production

See `azure/README.md`. In short: register an app in Microsoft Entra ID,
provision Azure resources with `azure/main.bicep`, populate Key Vault
secrets, deploy the app code, and set `APP_ENV=production`,
`DEV_AUTH_BYPASS=false`, `MAIL_ENABLED=true`.

## Key features

- SAP Fiori–style expandable table, inline spreadsheet-like editing,
  manual batch save.
- Delegation scoped by Data Entry Access value — a delegate only sees the
  rows their delegator explicitly granted, not the delegator's full set.
- Admin "Changes" view: rows edited away from their originally uploaded
  value, filterable, with a validated-with-modification vs
  validated-without-changes summary.
- Reminder emails to filter owners (single or bulk "remind all pending")
  via Microsoft Graph.

## Data model migration note

This version adds columns to `UserRow` (`original_values`,
`last_edited_by`, `last_edited_at`), to `Delegation`
(`data_entry_access_scope`), and changes `User` (drops `password_hash`,
adds `entra_oid`, `last_login_at`). `db.create_all()` only creates
*missing* tables — it does not alter existing ones. If you're upgrading a
database that already has data, apply a real migration (e.g. via
Alembic) or drop and recreate the schema in a non-production environment
before go-live.
