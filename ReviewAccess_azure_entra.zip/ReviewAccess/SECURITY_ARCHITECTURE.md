# BFC Access Review — Security & Architecture Overview

Prepared for security/architecture review prior to enterprise deployment on
Microsoft Azure. This document describes the current design; items marked
**[Recommendation]** are not yet implemented and are called out for the
review to weigh in on before go-live.

## 1. Purpose & data handled

A quarterly access-review workflow: an admin uploads an Excel export of
system access records, and each record's "filter owner" (a business
manager) reviews their own users and validates or deactivates their access.

**Data classification:** Internal / confidential. Records include employee
name, functional profile, access rights, and reporting unit — not
financial or health data, but personnel/access data that should be treated
as sensitive per standard internal-data handling policy.

## 2. High-level architecture

```
Filter Owners / Admins
        │  HTTPS
        ▼
Microsoft Entra ID  ──(OIDC sign-in)──►  Azure App Service (Linux, Python/Flask)
                                              │            │
                                     Key Vault│            │Azure DB for
                                    (secrets, │            │PostgreSQL
                                  via Managed │            │Flexible Server
                                    Identity) │            │
                                              ▼            ▼
                                     Microsoft Graph   Application Insights
                                     (Mail.Send, app-  / Log Analytics
                                      only, reminders)
```

See `azure/README.md` for the deployment-time view and the Bicep template
that provisions this.

## 3. Authentication

- **Mechanism:** OAuth 2.0 Authorization Code flow via OpenID Connect,
  implemented with MSAL for Python (`entra_auth.py`), against a
  single-tenant Entra ID App Registration.
- **No local passwords anywhere.** The `users` table has no password
  field; the app never sees or stores credentials. Identity is the Entra
  UPN (`preferred_username`), plus the Entra object id (`oid`) for a
  stable link if a UPN is ever renamed.
- **MFA / Conditional Access:** inherited from your tenant's existing
  policies for this app registration — this app does not implement or
  bypass MFA itself.
- **Session:** Flask-Login session cookie, `HttpOnly`, `SameSite=Lax`,
  `Secure` (enforced whenever `APP_ENV=production`), 8-hour default
  lifetime (`PERMANENT_SESSION_LIFETIME`, configurable).
- **CSRF on the auth flow:** a per-login `state` value is stored
  server-side in the session and checked on callback (`app.py`,
  `auth_callback`), rejecting mismatches with HTTP 400.
- **Sign-out:** clears the local session and redirects to Entra ID's
  logout endpoint, ending the SSO session too (not just this app's
  cookie).
- **Local development bypass:** `DEV_AUTH_BYPASS=true` swaps Entra
  sign-in for a plain "type an email" form (`login_dev.html`), gated
  three ways: (1) it's a separate route (`/login/dev`) never reachable
  unless the flag is set, (2) the flag defaults to `false`, and (3) the
  app **refuses to start** if `DEV_AUTH_BYPASS=true` and
  `APP_ENV=production` simultaneously (`app.py`, startup check).

## 4. Authorization

- **Roles:** `admin` and `filter_owner`, stored per-user in the local
  `users` table — not derived from Entra group/app-role claims in this
  version. **[Recommendation]**: if you'd prefer role assignment to live
  in Entra ID (App Roles or security groups reflected in the `roles`
  claim) rather than being admin-managed inside the app, this is a
  contained change in `_login_local_user()`.
- **Provisioning model:** an unrecognized UPN signing in is rejected
  (403) unless it's in `BOOTSTRAP_ADMIN_UPNS` (env-configured). All other
  accounts must be explicitly authorized by an existing admin (Admin →
  Users Management), which links a UPN to a business `owner_key` — this
  is what scopes which upload rows a filter owner can see.
- **Row-level scoping:** every owner-facing endpoint filters `UserRow` by
  the caller's `owner_key`, or — for delegates — by the specific
  `data_entry_access` values a delegation was scoped to
  (`get_visible_rows()` in `app.py`). A delegate never receives the
  owner's full row set, only the explicitly granted subset.
- **Route-level guards:** `@admin_required` / `@owner_required`
  decorators (`auth.py`) gate every admin/owner route; unauthenticated
  requests get redirected to sign-in, unauthorized ones get 401/403.

## 5. Secrets management

- No secret values are stored in source control. `.env` is git-ignored;
  `.env.example` documents variable names only.
- In Azure, all secrets (`SECRET_KEY`, `ENTRA_CLIENT_SECRET`,
  `DATABASE_URL`, `MAIL_SENDER_UPN`, `BOOTSTRAP_ADMIN_UPNS`) are Key
  Vault references in App Service Application Settings, resolved at
  runtime via the Web App's **system-assigned managed identity** (Key
  Vault Secrets User role, least-privilege — read-only, no list/write).
- `config.py` fails fast (`RuntimeError`) if `SECRET_KEY` or
  `DATABASE_URL` are missing when `APP_ENV=production`, rather than
  silently falling back to an insecure default.

## 6. Data protection

- **In transit:** App Service is `httpsOnly: true`, `minTlsVersion: 1.2`.
  PostgreSQL connections use `sslmode=require`. Graph calls go over TLS
  to `graph.microsoft.com`.
- **At rest:** Azure Database for PostgreSQL encrypts data at rest by
  default (Microsoft-managed keys). **[Recommendation]** — if your
  policy requires customer-managed keys (CMK), that's a Postgres Flexible
  Server configuration change, not an app change.
- **Audit trail:** every inline field edit records `last_edited_by` /
  `last_edited_at` on the row; every validate/deactivate decision records
  `validator` / `validated_at`. The Admin "Changes" tab surfaces exactly
  which fields were modified from the originally uploaded value, by whom,
  and when.

## 7. Email (Microsoft Graph)

- Reminders are sent via Graph's `sendMail` using **application**
  permissions (client-credentials flow, `mailer.py`) — not delegated —
  because reminders are triggered by an admin action, not sent "as" the
  signed-in admin.
- **Least privilege:** `Mail.Send` is an application-wide Graph
  permission by default, which would let the app send as *any* mailbox
  in the tenant. `azure/README.md` documents restricting this to a
  single mailbox via an Exchange Online `ApplicationAccessPolicy` scoped
  to the app's client ID — this should be treated as a required step,
  not optional hardening.
- `MAIL_ENABLED=false` (the safe default) makes `send_mail()` a no-op
  that only logs, so non-production environments never need real Graph
  credentials or risk sending real reminder emails.

## 8. Network **[Recommendation — not yet implemented]**

The current Bicep template uses public network access with firewall
rules for a first deployment, to keep the initial review simpler. For
production we recommend:

- VNet-integrate the Web App (Regional VNet Integration).
- Private Endpoints for PostgreSQL Flexible Server and Key Vault; disable
  their public network access once endpoints are in place.
- If this app must sit behind your standard edge/WAF, front it with Azure
  Front Door or Application Gateway rather than exposing
  `*.azurewebsites.net` directly.

## 9. Logging & monitoring

- Application Insights + Log Analytics workspace (90-day retention in the
  template, adjust to your retention policy) capture request telemetry.
- Recommend alerting on: repeated 401/403s (possible enumeration/misuse),
  Graph `sendMail` failures, and PostgreSQL connection failures.
- Business-level audit data (who edited what, who validated what, when)
  lives in the application database itself (see §6), independent of
  infrastructure logs.

## 10. Dependencies / supply chain

- `requirements.txt` — no local password hashing library needed anymore
  (removed `flask-bcrypt`); added `msal`, `azure-identity`,
  `azure-keyvault-secrets`, `psycopg2-binary`, `opencensus-ext-*`.
  **[Recommendation]**: pin exact versions (`==`) once this passes review,
  and enable Dependabot/renovate for patching.

## 11. Known gaps / open questions for this review

1. Should role assignment (`admin` vs `filter_owner`) come from Entra ID
   App Roles/groups instead of being admin-managed in-app? (§4)
2. Confirm acceptable approach for PostgreSQL admin credentials —
   Entra-only auth vs. the password parameter the template currently
   takes. (`azure/README.md`)
3. Confirm retention policy for `UserRow`/`ReviewSession` data across
   review cycles (currently indefinite — no automated purge).
4. Confirm whether this needs to sit behind an existing WAF/edge, and on
   a custom domain rather than `*.azurewebsites.net`.
