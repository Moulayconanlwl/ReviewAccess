import logging
import secrets

from flask import (Flask, render_template, request, jsonify,
                   send_file, redirect, url_for, abort, session)
from flask_login import (LoginManager, login_user, logout_user,
                         login_required, current_user)
import pandas as pd
from io import BytesIO
from datetime import datetime

from config import Config
from models import db, User, ReviewSession, UserRow, Delegation
from auth import admin_required, owner_required
import entra_auth
import mailer

app = Flask(__name__)
app.config.from_object(Config)

if app.config["DEV_AUTH_BYPASS"] and app.config["APP_ENV"] == "production":
    raise RuntimeError("DEV_AUTH_BYPASS must never be enabled when APP_ENV=production")

# Application Insights request tracing (no-op if connection string unset)
if app.config.get("APPLICATIONINSIGHTS_CONNECTION_STRING"):
    try:
        from opencensus.ext.azure.log_exporter import AzureLogHandler
        from opencensus.ext.flask.flask_middleware import FlaskMiddleware
        FlaskMiddleware(app, exporter=None)  # request tracing via env-configured exporter
        logging.getLogger().addHandler(
            AzureLogHandler(connection_string=app.config["APPLICATIONINSIGHTS_CONNECTION_STRING"])
        )
    except Exception:
        app.logger.exception("Failed to initialize Application Insights — continuing without it")

db.init_app(app)

login_manager = LoginManager(app)
login_manager.login_view = "login_page"
login_manager.login_message = "Please sign in to access this page."

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

with app.app_context():
    db.create_all()


# Fields a filter owner (or scoped delegate) may edit inline.
# NOTE: "data_entry_access" and "location" are intentionally NOT
# editable/displayed to filter owners anymore. "data_entry_access" is
# still stored on each row and is used to scope delegated access
# (see Delegation.data_entry_access_scope).
EDITABLE_FIELDS = {
    "functional_profile",
    "bfc_reporting_unit",
    "entity_name",
    "access_right",
}


def get_active_session():
    return ReviewSession.query.order_by(ReviewSession.created_at.desc()).first()


def get_visible_rows(review, owner_key, code=None):
    """Return the UserRow records visible to `owner_key` for `review`:
    all of their own rows, plus any rows delegated to them, restricted
    to the data_entry_access values each delegation was scoped to.
    """
    if not review or not owner_key:
        return []

    delegations = Delegation.query.filter_by(
        session_id=review.id, delegate_key=owner_key
    ).all()
    scope_map = {d.owner_key: set(d.data_entry_access_scope or []) for d in delegations}

    relevant_owners = list(set([owner_key] + list(scope_map.keys())))

    query = UserRow.query.filter_by(session_id=review.id).filter(
        UserRow.filter_owner.in_(relevant_owners)
    )
    if code:
        query = query.filter_by(code=code)

    visible = []
    for row in query.all():
        if row.filter_owner == owner_key:
            visible.append(row)
        else:
            allowed = scope_map.get(row.filter_owner, set())
            if allowed and row.data_entry_access in allowed:
                visible.append(row)
    return visible


def compute_owner_pct(review, owner_key):
    rows = UserRow.query.filter_by(session_id=review.id, filter_owner=owner_key).all()
    users = {}
    for r in rows:
        users.setdefault(r.code, []).append(r)
    total = len(users)
    if total == 0:
        return 0
    done = sum(
        1 for user_rows in users.values()
        if all(r.choice in ("validate", "deactivate") for r in user_rows)
    )
    return round(done / total * 100)


def _login_local_user(upn, display_name=None, oid=None):
    """Find or provision the local User row for an authenticated UPN,
    then start the Flask-Login session. Returns the User, or None if
    this identity is not authorized (not pre-provisioned and not a
    bootstrap admin)."""
    user = User.query.filter_by(email=upn).first()

    if not user:
        if upn in app.config["BOOTSTRAP_ADMIN_UPNS"]:
            user = User(email=upn, role="admin", entra_oid=oid)
            db.session.add(user)
        else:
            return None  # must be pre-provisioned by an admin with an owner_key

    if oid and not user.entra_oid:
        user.entra_oid = oid
    user.last_login_at = datetime.utcnow()
    db.session.commit()

    login_user(user, remember=True)
    return user


# ── Auth: Microsoft Entra ID (OIDC) ─────────────────────────────────────────
@app.route("/login", methods=["GET"])
def login_page():
    if current_user.is_authenticated:
        return redirect(url_for("index"))

    if app.config["DEV_AUTH_BYPASS"]:
        return render_template("login_dev.html", error=request.args.get("error"))

    state = secrets.token_urlsafe(24)
    session["auth_state"] = state
    return redirect(entra_auth.build_auth_url(state))


@app.route("/login/dev", methods=["POST"])
def login_dev():
    """Local-development-only sign-in bypass. Disabled unless
    DEV_AUTH_BYPASS=true, and refused outright if APP_ENV=production
    (see startup check above)."""
    if not app.config["DEV_AUTH_BYPASS"]:
        abort(404)
    upn = request.form.get("email", "").lower().strip()
    user = _login_local_user(upn)
    if not user:
        return redirect(url_for("login_page", error="Unknown account. Ask an admin to add you."))
    return redirect(url_for("index"))


@app.route("/auth/callback")
def auth_callback():
    if request.args.get("error"):
        return render_template(
            "login.html",
            error=request.args.get("error_description", "Sign-in failed.")
        ), 401

    if request.args.get("state") != session.pop("auth_state", None):
        abort(400, "Invalid auth state")

    code = request.args.get("code")
    if not code:
        abort(400, "Missing authorization code")

    result = entra_auth.acquire_token_by_auth_code(code)
    if "error" in result:
        app.logger.warning("Entra sign-in failed: %s", result.get("error_description"))
        return render_template("login.html", error="Sign-in failed. Please try again."), 401

    identity = entra_auth.extract_identity(result)
    if not identity["upn"]:
        return render_template("login.html", error="Could not read your account details."), 401

    user = _login_local_user(identity["upn"], identity["name"], identity["oid"])
    if not user:
        return render_template(
            "login.html",
            error=f"'{identity['upn']}' is not authorized. Ask an admin to add your account."
        ), 403

    return redirect(url_for("index"))


@app.route("/logout")
@login_required
def logout():
    logout_user()
    session.clear()
    if app.config["DEV_AUTH_BYPASS"]:
        return redirect(url_for("login_page"))
    return redirect(entra_auth.build_logout_url())

@app.route("/")
@login_required
def index():
    if current_user.role == "admin":
        return render_template("admin.html", user=current_user)
    return render_template("index.html", user=current_user)

@app.errorhandler(403)
def forbidden(_):
    return render_template("login.html", error="Access denied. You do not have permission."), 403

@app.errorhandler(401)
def unauthorized(_):
    return redirect(url_for("login_page"))


# ── Admin: User Management ────────────────────────────────────────────────────
# NOTE: there is no password here anymore. "Creating" a filter owner account
# just pre-authorizes an Entra ID UPN to sign in and maps it to an owner_key.
# The person still authenticates via Microsoft Entra ID (SSO); nothing is
# provisioned in Entra ID itself by this app.
@app.route("/admin/users", methods=["GET"])
@admin_required
def list_users():
    users = User.query.filter(User.role != "admin").all()
    return jsonify([{
        "id": u.id, "email": u.email,
        "role": u.role, "owner_key": u.owner_key,
        "last_login_at": u.last_login_at,
    } for u in users])

@app.route("/admin/users/create", methods=["POST"])
@admin_required
def create_user():
    data = request.json
    email = (data.get("email") or "").lower().strip()
    if not email:
        return jsonify({"error": "Entra ID email/UPN is required"}), 400
    if User.query.filter_by(email=email).first():
        return jsonify({"error": "That account is already registered"}), 400
    user = User(
        email=email,
        role="filter_owner",
        owner_key=(data.get("owner_key") or "").strip()
    )
    db.session.add(user)
    db.session.commit()
    return jsonify({"success": True, "id": user.id})

@app.route("/admin/users/<int:user_id>", methods=["PUT"])
@admin_required
def update_user(user_id):
    user = User.query.get_or_404(user_id)
    data = request.json
    if "owner_key" in data:
        user.owner_key = data["owner_key"].strip()
    if "email" in data and data["email"]:
        user.email = data["email"].lower().strip()
    db.session.commit()
    return jsonify({"success": True})

@app.route("/admin/users/<int:user_id>", methods=["DELETE"])
@admin_required
def delete_user(user_id):
    user = User.query.get_or_404(user_id)
    db.session.delete(user)
    db.session.commit()
    return jsonify({"success": True})


# ── Admin: Upload ─────────────────────────────────────────────────────────────
@app.route("/admin/upload", methods=["POST"])
@admin_required
def upload_file():
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded", "success": False}), 400
    file = request.files["file"]
    if not file.filename.endswith(".xlsx"):
        return jsonify({"error": "Please upload an .xlsx file", "success": False}), 400
    try:
        df = pd.read_excel(file, engine="openpyxl")
        df.columns = [str(c).strip() for c in df.columns]
        if "Data entry filter owner" not in df.columns:
            return jsonify({"error": "Column 'Data entry filter owner' not found", "success": False}), 400

        session_id = datetime.now().strftime("%Y%m%d%H%M%S%f")
        review = ReviewSession(
            id=session_id,
            deadline=request.form.get("deadline", ""),
            quarter=request.form.get("quarter", ""),
            created_by=current_user.email,
        )
        db.session.add(review)

        col_map = {
    "Code": "code",
    "User Name": "user_name",
    "Functional Profile": "functional_profile",
    "Data entry access": "data_entry_access",
    "Manager": "manager",
    "Département": "departement",
    "Location": "location",
    "Data entry filter owner": "filter_owner",
    "Active BFC": "active_bfc",
    "Active AD": "active_ad",
    "BFC Reporting Unit": "bfc_reporting_unit",
    "Entity Name": "entity_name",
    "Access Right": "access_right",
}

        for _, row in df.iterrows():
            known = {}
            for excel_col, db_col in col_map.items():
                val = row.get(excel_col)
                known[db_col] = str(val) if (val is not None and not (isinstance(val, float) and pd.isna(val))) else None
            extra = {
                c: (str(row[c]) if not (isinstance(row[c], float) and pd.isna(row[c])) else None)
                for c in df.columns if c not in col_map
            }
            original_values = {field: known.get(field) for field in EDITABLE_FIELDS}
            db.session.add(UserRow(
                session_id=session_id, **known, extra_data=extra,
                original_values=original_values,
            ))

        db.session.commit()
        owners_in_file = df["Data entry filter owner"].dropna().unique().tolist()
        return jsonify({
            "success": True,
            "session_id": session_id,
            "total_rows": len(df),
            "owners_in_file": owners_in_file
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e), "success": False}), 500


# ── Admin: Stats & Export ─────────────────────────────────────────────────────
@app.route("/admin/stats")
@admin_required
def admin_stats():
    review = get_active_session()
    if not review:
        return jsonify({"error": "No active session found"}), 404

    rows = UserRow.query.filter_by(session_id=review.id).all()
    users = {}
    for r in rows:
        users.setdefault(r.code, []).append(r)

    total = len(users)
    validated = deactivated = pending = 0
    for code, u_rows in users.items():
        if all(r.choice == "validate" for r in u_rows):
            validated += 1
        elif all(r.choice == "deactivate" for r in u_rows):
            deactivated += 1
        else:
            pending += 1

    pct = round((validated + deactivated) / total * 100) if total > 0 else 0

    owner_users = {}
    for code, u_rows in users.items():
        owner = u_rows[0].filter_owner
        owner_users.setdefault(owner, {})
        owner_users[owner][code] = u_rows

    delegations = {
        d.owner_key: d.delegate_key
        for d in Delegation.query.filter_by(session_id=review.id).all()
    }

    owners_stats = []
    for owner, u_map in owner_users.items():
        o_total = len(u_map)
        o_valid = o_deact = o_pending = 0
        for code, u_rows in u_map.items():
            if all(r.choice == "validate" for r in u_rows):
                o_valid += 1
            elif all(r.choice == "deactivate" for r in u_rows):
                o_deact += 1
            else:
                o_pending += 1
        o_pct = round((o_valid + o_deact) / o_total * 100) if o_total > 0 else 0
        status = ("Terminated" if o_pct == 100 else "In progress" if o_pct > 0 else "Not started")
        last_dt = None
        for _, user_rows in u_map.items():
            for r in user_rows:
                if r.validated_at:
                    last_dt = max(last_dt, r.validated_at) if last_dt else r.validated_at
        owners_stats.append({
            "code": owner, "name": owner, "pct": o_pct, "status": status,
            "last_date": last_dt.strftime("%d/%m/%Y") if last_dt else "",
            "delegation": delegations.get(owner, ""),
            "total": o_total, "deactivated": o_deact,
        })

    return jsonify({
        "success": True, "total": total, "validated": validated,
        "deactivated": deactivated, "pending": pending, "pct": pct,
        "deadline": review.deadline, "quarter": review.quarter,
        "owners_stats": owners_stats,
    })

@app.route("/admin/export")
@admin_required
def admin_export():
    review = get_active_session()
    if not review:
        abort(404)
    rows = UserRow.query.filter_by(session_id=review.id).all()
    data = [{
        "Code": r.code, "User Name": r.user_name,
        "Functional Profile": r.functional_profile,
        "Data entry access": r.data_entry_access,
        "Manager": r.manager, "Département": r.departement,
        "Location": r.location, "Filter Owner": r.filter_owner,
        "BFC Reporting Unit": r.bfc_reporting_unit,
        "Entity Name": r.entity_name,
        "Active BFC": r.active_bfc, "Choice": r.choice,
        "Validator": r.validator, "Validated At": r.validated_at
    } for r in rows]
    df       = pd.DataFrame(data)
    deact_df = df[df["Choice"] == "deactivate"].copy()
    output   = BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="All Users")
        deact_df.to_excel(writer, index=False, sheet_name="Deactivated")
    output.seek(0)
    return send_file(output, as_attachment=True,
                     download_name=f"admin_review_{datetime.now().strftime('%Y%m%d')}.xlsx",
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


# ── Admin: Reminders ───────────────────────────────────────────────────────────
@app.route("/admin/remind/<owner_key>", methods=["POST"])
@admin_required
def remind_owner(owner_key):
    review = get_active_session()
    if not review:
        return jsonify({"error": "No active review session"}), 404

    recipients = [u.email for u in User.query.filter_by(owner_key=owner_key).all()]
    if not recipients:
        return jsonify({"error": f"No registered account found for owner key '{owner_key}'"}), 404

    pct = compute_owner_pct(review, owner_key)
    try:
        sent = mailer.send_mail(
            recipients,
            subject=f"[Action Required] BFC Access Review — {pct}% complete",
            html_body=mailer.reminder_email_body(owner_key, review.deadline, pct),
        )
    except mailer.MailError as e:
        app.logger.warning("Reminder email failed for %s: %s", owner_key, e)
        return jsonify({"error": str(e)}), 502

    return jsonify({"success": True, "sent": sent, "recipients": recipients})


@app.route("/admin/remind_all", methods=["POST"])
@admin_required
def remind_all_pending():
    review = get_active_session()
    if not review:
        return jsonify({"error": "No active review session"}), 404

    owner_keys = [
        row[0] for row in
        db.session.query(UserRow.filter_owner).filter_by(session_id=review.id).distinct().all()
        if row[0]
    ]

    results = []
    for owner_key in owner_keys:
        pct = compute_owner_pct(review, owner_key)
        if pct >= 100:
            continue
        recipients = [u.email for u in User.query.filter_by(owner_key=owner_key).all()]
        if not recipients:
            results.append({"owner_key": owner_key, "sent": False, "reason": "no registered account"})
            continue
        try:
            sent = mailer.send_mail(
                recipients,
                subject=f"[Action Required] BFC Access Review — {pct}% complete",
                html_body=mailer.reminder_email_body(owner_key, review.deadline, pct),
            )
            results.append({"owner_key": owner_key, "sent": sent})
        except mailer.MailError as e:
            results.append({"owner_key": owner_key, "sent": False, "reason": str(e)})

    return jsonify({"success": True, "results": results})


# ── Filter Owner Routes ───────────────────────────────────────────────────────
@app.route("/my/users")
@owner_required
def get_my_users():
    review = get_active_session()
    if not review:
        return jsonify({"error": "No active review session"}), 404

    owner_key = current_user.owner_key or ""
    rows = get_visible_rows(review, owner_key)

    seen = {}
    for r in rows:
        if r.code not in seen:
            seen[r.code] = {
                "code": r.code, "user_name": r.user_name,
                "functional_profile": set(),
                "manager": r.manager,
                "choice": r.choice, "line_count": 0,
                "modified": False,
            }
        entry = seen[r.code]
        entry["line_count"] += 1
        if r.functional_profile:
            entry["functional_profile"].add(r.functional_profile)
        if r.is_modified(EDITABLE_FIELDS):
            entry["modified"] = True

    users = []
    for entry in seen.values():
        entry["functional_profile"] = ", ".join(sorted(entry["functional_profile"])) or None
        users.append(entry)

    return jsonify({
        "success": True,
        "users": users,
        "deadline": review.deadline,
        "quarter": review.quarter,
    })

@app.route("/my/user/<code>/details")
@owner_required
def get_user_details(code):
    review = get_active_session()
    if not review:
        return jsonify({"error": "No active review session"}), 404

    owner_key = current_user.owner_key or ""
    rows = get_visible_rows(review, owner_key, code=code)
    if not rows:
        abort(404)

    return jsonify({
        "success": True,
        "code": code,
        "user_name": rows[0].user_name,
        "details": [{
            "id": r.id,
            "code": r.code,
            "user_name": r.user_name,
            "functional_profile": r.functional_profile,
            "bfc_reporting_unit": r.bfc_reporting_unit,
            "entity_name": r.entity_name,
            "access_right": r.access_right,
            "active_bfc": r.active_bfc,
            "active_ad": r.active_ad,
            "choice": r.choice,
            "modified": r.is_modified(EDITABLE_FIELDS),
            "extra": r.extra_data or {},
        } for r in rows]
    })

@app.route("/my/update_choice", methods=["POST"])
@owner_required
def update_choice():
    data   = request.json
    code   = data.get("code")
    choice = data.get("choice")
    if choice not in ("validate", "deactivate", "pending"):
        return jsonify({"error": "Invalid choice"}), 400

    review = get_active_session()
    if not review:
        return jsonify({"error": "No active review session"}), 404

    owner_key = current_user.owner_key or ""
    rows = get_visible_rows(review, owner_key, code=code)
    for r in rows:
        r.choice      = choice
        r.validator   = current_user.email
        r.validated_at = datetime.utcnow() if choice != "pending" else None
    db.session.commit()
    return jsonify({"success": True, "updated": len(rows)})


@app.route("/my/update_field", methods=["POST"])
@owner_required
def update_field():
    data   = request.json
    row_id = data.get("row_id")
    field  = data.get("field")
    value  = data.get("value", "")

    if field not in EDITABLE_FIELDS:
        return jsonify({"error": f"Field '{field}' is not editable"}), 400

    review = get_active_session()
    if not review:
        return jsonify({"error": "No active review session"}), 404

    owner_key = current_user.owner_key or ""
    visible_ids = {r.id for r in get_visible_rows(review, owner_key)}

    row = UserRow.query.get_or_404(row_id)
    if row.session_id != review.id or row.id not in visible_ids:
        abort(403)

    setattr(row, field, value.strip() if value else None)
    row.last_edited_by = current_user.email
    row.last_edited_at = datetime.utcnow()
    db.session.commit()
    return jsonify({"success": True, "row_id": row_id, "field": field, "value": value})


@app.route("/my/signoff", methods=["POST"])
@owner_required
def signoff():
    review = get_active_session()
    if not review:
        return jsonify({"error": "No active review session"}), 404

    owner_key = current_user.owner_key or ""
    rows = UserRow.query.filter_by(session_id=review.id, filter_owner=owner_key).all()
    for r in rows:
        r.signoff_at = datetime.utcnow()
    db.session.commit()

    # Summary: among codes fully validated, how many had at least one
    # modified line vs how many were validated exactly as imported.
    users = {}
    for r in rows:
        users.setdefault(r.code, []).append(r)
    validated_with_changes = validated_without_changes = 0
    for code, user_rows in users.items():
        if all(r.choice == "validate" for r in user_rows):
            if any(r.is_modified(EDITABLE_FIELDS) for r in user_rows):
                validated_with_changes += 1
            else:
                validated_without_changes += 1

    return jsonify({
        "success": True,
        "summary": {
            "validated_with_changes": validated_with_changes,
            "validated_without_changes": validated_without_changes,
        },
    })

@app.route("/my/stats")
@owner_required
def my_stats():
    review = get_active_session()
    if not review:
        return jsonify({"error": "No active review session"}), 404

    owner_key = current_user.owner_key or ""
    rows = UserRow.query.filter_by(session_id=review.id, filter_owner=owner_key).all()
    users = {}
    for r in rows:
        users.setdefault(r.code, []).append(r)
    total = len(users)
    validated = deactivated = pending = 0
    for code, user_rows in users.items():
        if all(r.choice == "validate" for r in user_rows):
            validated += 1
        elif all(r.choice == "deactivate" for r in user_rows):
            deactivated += 1
        else:
            pending += 1
    pct = round((validated + deactivated) / total * 100) if total > 0 else 0
    return jsonify({
        "success": True, "total": total,
        "validated": validated, "deactivated": deactivated,
        "pending": pending, "pct": pct, "deadline": review.deadline,
    })

@app.route("/my/data_entry_access_values")
@owner_required
def my_data_entry_access_values():
    """Distinct data_entry_access values found in the current owner's
    own rows, used to build the delegation scope picker."""
    review = get_active_session()
    if not review:
        return jsonify({"error": "No active review session"}), 404

    owner_key = current_user.owner_key or ""
    values = (
        db.session.query(UserRow.data_entry_access)
        .filter_by(session_id=review.id, filter_owner=owner_key)
        .distinct()
        .all()
    )
    values = sorted({v[0] for v in values if v[0]})
    return jsonify({"success": True, "values": values})

@app.route("/my/delegate", methods=["POST"])
@owner_required
def set_delegation():
    data         = request.json
    delegate_key = data.get("delegate_key", "").strip()
    scope        = data.get("data_entry_access") or []
    scope        = [str(v).strip() for v in scope if str(v).strip()]

    if delegate_key and not scope:
        return jsonify({"error": "Select at least one Data Entry Access value to delegate"}), 400

    review    = get_active_session()
    if not review:
        return jsonify({"error": "No active review session"}), 404

    owner_key = current_user.owner_key or ""
    existing = Delegation.query.filter_by(session_id=review.id, owner_key=owner_key).first()
    if existing:
        existing.delegate_key = delegate_key
        existing.data_entry_access_scope = scope
    else:
        db.session.add(Delegation(
            session_id=review.id, owner_key=owner_key,
            delegate_key=delegate_key, data_entry_access_scope=scope,
        ))
    db.session.commit()
    return jsonify({"success": True})

@app.route("/my/export")
@owner_required
def export_my_data():
    review    = get_active_session()
    if not review:
        abort(404)
    owner_key = current_user.owner_key or ""
    rows      = UserRow.query.filter_by(session_id=review.id, filter_owner=owner_key).all()
    data = [{
        "Code": r.code, "User Name": r.user_name,
        "Functional Profile": r.functional_profile,
        "Manager": r.manager, "Département": r.departement,
        "BFC Reporting Unit": r.bfc_reporting_unit,
        "Entity Name": r.entity_name,
        "Choice": r.choice
    } for r in rows]
    df     = pd.DataFrame(data)
    output = BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="My Users")
    output.seek(0)
    return send_file(output, as_attachment=True,
                     download_name="my_review.xlsx",
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


# ── Admin: Change Tracking ────────────────────────────────────────────────────
@app.route("/admin/changes")
@admin_required
def admin_changes():
    """Rows edited by filter owners/delegates, with a changed/all filter,
    plus a validated-with-modification vs validated-without-changes summary.
    """
    review = get_active_session()
    if not review:
        return jsonify({"error": "No active session found"}), 404

    show = request.args.get("filter", "changed")  # "changed" | "all"
    rows = UserRow.query.filter_by(session_id=review.id).all()

    changed_rows = []
    for r in rows:
        is_mod = r.is_modified(EDITABLE_FIELDS)
        if show == "changed" and not is_mod:
            continue
        diffs = []
        if r.original_values:
            for field in sorted(EDITABLE_FIELDS):
                original = r.original_values.get(field)
                current = getattr(r, field)
                if (current or None) != (original or None):
                    diffs.append({"field": field, "original": original, "current": current})
        changed_rows.append({
            "id": r.id, "code": r.code, "user_name": r.user_name,
            "filter_owner": r.filter_owner, "choice": r.choice,
            "modified": is_mod, "changes": diffs,
            "edited_by": r.last_edited_by, "edited_at": r.last_edited_at,
        })

    # Org-wide summary: among fully-validated codes, how many had at
    # least one modified line vs how many were validated unmodified.
    users = {}
    for r in rows:
        users.setdefault(r.code, []).append(r)
    validated_with_changes = validated_without_changes = 0
    for code, user_rows in users.items():
        if all(r.choice == "validate" for r in user_rows):
            if any(r.is_modified(EDITABLE_FIELDS) for r in user_rows):
                validated_with_changes += 1
            else:
                validated_without_changes += 1

    return jsonify({
        "success": True,
        "filter": show,
        "rows": changed_rows,
        "summary": {
            "validated_with_changes": validated_with_changes,
            "validated_without_changes": validated_without_changes,
        },
    })


if __name__ == "__main__":
    app.run(debug=True, port=5000)