# Deploying BFC Access Review to Azure

This folder contains the infrastructure-as-code (`main.bicep`) for a first
production deployment. It's meant as a concrete starting point for your
security/architecture review — see `../SECURITY_ARCHITECTURE.md` for the
control-by-control writeup.

## Architecture at a glance

```
                    ┌────────────────────┐
   Filter Owners /  │  Microsoft Entra ID │  Sign-in (OIDC), tenant-restricted
   Admins  ───────► │  (Azure AD)         │
                    └─────────┬──────────┘
                              │ redirect / id_token
                              ▼
                    ┌────────────────────┐        ┌───────────────────┐
                    │  Azure App Service   │──────►│  Key Vault          │
                    │  (Linux, Python)     │  MI    │  (secrets)          │
                    │  BFC Access Review   │        └───────────────────┘
                    └─────────┬──────────┘
                              │ SSL
                              ▼
                    ┌────────────────────┐        ┌───────────────────┐
                    │  Azure Database for  │        │  Microsoft Graph    │
                    │  PostgreSQL Flexible │        │  (Mail.Send, app-   │
                    │  Server              │        │  only, reminders)   │
                    └────────────────────┘        └───────────────────┘
                              │
                              ▼
                    ┌────────────────────┐
                    │  Application Insights│
                    │  / Log Analytics      │
                    └────────────────────┘
```

## 1. Register the app in Microsoft Entra ID

1. Azure Portal → **Microsoft Entra ID** → **App registrations** → **New registration**.
   - Name: `BFC Access Review`
   - Supported account types: **Single tenant** (your org only).
   - Redirect URI (Web): `https://<your-app-name>.azurewebsites.net/auth/callback`
2. **Certificates & secrets** → new client secret → copy the value (this becomes `ENTRA_CLIENT_SECRET`).
3. **API permissions** → add:
   - `Microsoft Graph` → **Delegated** → `User.Read` (sign-in, usually pre-added).
   - `Microsoft Graph` → **Application** → `Mail.Send` → **Grant admin consent**.
4. (Recommended hardening) In Exchange Online, restrict which mailbox this
   app can send as, using an application access policy scoped to the app's
   client ID and the `MAIL_SENDER_UPN` mailbox only:
   ```powershell
   New-ApplicationAccessPolicy -AppId <ENTRA_CLIENT_ID> `
     -PolicyScopeGroupId reviews@yourtenant.com -AccessRight RestrictAccess `
     -Description "Restrict BFC Access Review app to the reviews mailbox"
   ```
5. Note down: **Application (client) ID**, **Directory (tenant) ID**, and the client secret.

## 2. Provision Azure resources

```bash
az login
az group create --name rg-bfc-review --location westeurope

az deployment group create \
  --resource-group rg-bfc-review \
  --template-file main.bicep \
  --parameters appName=bfcreview environmentName=prod \
               postgresAdminLogin=bfcadmin \
               postgresAdminPassword='<generate-a-strong-password>' \
               entraTenantId='<tenant-id>' \
               entraClientId='<client-id>'
```

This creates: App Service Plan + Web App, PostgreSQL Flexible Server, Key
Vault, Application Insights/Log Analytics, and grants the Web App's
managed identity read access to Key Vault secrets.

## 3. Populate Key Vault secrets

The Bicep template wires App Service settings to Key Vault references, but
does **not** populate secret values (so they're never in source control or
deployment logs). Set them after provisioning:

```bash
KV=<keyVaultName output from the deployment>

az keyvault secret set --vault-name $KV --name app-secret-key \
  --value "$(python3 -c 'import secrets; print(secrets.token_urlsafe(48))')"

az keyvault secret set --vault-name $KV --name entra-client-secret --value '<client secret from step 1>'

az keyvault secret set --vault-name $KV --name database-url \
  --value "postgresql+psycopg2://bfcadmin:<password>@<postgresServerFqdn>:5432/bfc?sslmode=require"

az keyvault secret set --vault-name $KV --name mail-sender-upn --value 'reviews@yourtenant.com'

az keyvault secret set --vault-name $KV --name bootstrap-admin-upns --value 'you@yourtenant.com'
```

## 4. Deploy the application code

Zip-deploy (simplest) or wire up the included GitHub Actions workflow
(`.github/workflows/azure-deploy.yml`):

```bash
zip -r app.zip . -x "azure/*" ".git/*" "*.db"
az webapp deploy --resource-group rg-bfc-review --name <webAppName> --src-path app.zip --type zip
```

Confirm the **Startup Command** in App Service → Configuration → General
settings is `startup.sh` (the Bicep template sets this already).

## 5. Post-deploy checks

- Browse to `https://<app>.azurewebsites.net/login` → should redirect to
  Microsoft sign-in.
- Sign in with one of the `BOOTSTRAP_ADMIN_UPNS` accounts → should land on
  the Admin panel.
- Upload a test file, create a filter-owner account, send a test reminder
  (Monitoring tab → Remind), confirm delivery.
- Application Insights → Live Metrics should show inbound requests.

## Production hardening not yet in this template

These are flagged for the architecture review rather than pre-built, since
they depend on your existing network/landing-zone conventions:

- **VNet integration** for the Web App + **Private Endpoints** for
  PostgreSQL and Key Vault (this template uses public access with
  firewall rules for a first deployment).
- **Entra-only PostgreSQL authentication** instead of the admin
  login/password parameter, once your DBA team's Postgres AAD auth
  pattern is confirmed.
- **Custom domain + WAF** (Azure Front Door or Application Gateway) in
  front of the Web App if this needs to sit behind your standard edge.
- **Conditional Access / MFA** policy targeting this app's users — inherited
  from your tenant, not configured by this template.
