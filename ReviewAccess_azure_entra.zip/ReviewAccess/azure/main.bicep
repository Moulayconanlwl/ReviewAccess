// main.bicep — BFC Access Review, Azure infrastructure
//
// Provisions:
//   - Linux App Service Plan + Web App (Python), HTTPS-only, system-assigned Managed Identity
//   - Azure Database for PostgreSQL Flexible Server (private access recommended — see notes)
//   - Key Vault, with the Web App's Managed Identity granted "get" on secrets
//   - Application Insights + Log Analytics workspace
//
// This is a starting point for the security/architecture review, not a
// finished production topology. In particular, for production we strongly
// recommend adding VNet integration + Private Endpoints for the Web App,
// PostgreSQL, and Key Vault (see SECURITY_ARCHITECTURE.md "Network").

@description('Short name used to derive resource names, e.g. "bfcreview"')
param appName string = 'bfcreview'

@description('Deployment environment tag')
@allowed(['dev', 'test', 'prod'])
param environmentName string = 'prod'

@description('Azure region for all resources')
param location string = resourceGroup().location

@description('Administrator login for the PostgreSQL Flexible Server')
param postgresAdminLogin string

@secure()
@description('Administrator password for the PostgreSQL Flexible Server. Prefer Entra-only auth in production (see notes below).')
param postgresAdminPassword string

@description('SKU for the App Service Plan')
param appServicePlanSku string = 'P1v3'

@description('Entra ID (Azure AD) application (client) ID for sign-in — set after app registration')
param entraClientId string = ''

@description('Entra ID tenant ID')
param entraTenantId string = ''

var resourceSuffix = '${appName}-${environmentName}'
var keyVaultName = take('kv-${resourceSuffix}', 24)
var logAnalyticsName = 'log-${resourceSuffix}'
var appInsightsName = 'appi-${resourceSuffix}'
var planName = 'plan-${resourceSuffix}'
var webAppName = 'app-${resourceSuffix}'
var postgresServerName = 'psql-${resourceSuffix}'
var postgresDbName = 'bfc'

resource logAnalytics 'Microsoft.OperationalInsights/workspaces@2022-10-01' = {
  name: logAnalyticsName
  location: location
  properties: {
    sku: { name: 'PerGB2018' }
    retentionInDays: 90
  }
}

resource appInsights 'Microsoft.Insights/components@2020-02-02' = {
  name: appInsightsName
  location: location
  kind: 'web'
  properties: {
    Application_Type: 'web'
    WorkspaceResourceId: logAnalytics.id
  }
}

resource keyVault 'Microsoft.KeyVault/vaults@2023-07-01' = {
  name: keyVaultName
  location: location
  properties: {
    sku: { family: 'A', name: 'standard' }
    tenantId: subscription().tenantId
    enableRbacAuthorization: true
    enableSoftDelete: true
    softDeleteRetentionInDays: 90
    publicNetworkAccess: 'Enabled' // recommend 'Disabled' + Private Endpoint for production
  }
}

resource postgresServer 'Microsoft.DBforPostgreSQL/flexibleServers@2023-06-01-preview' = {
  name: postgresServerName
  location: location
  sku: {
    name: 'Standard_D2ds_v4'
    tier: 'GeneralPurpose'
  }
  properties: {
    version: '16'
    administratorLogin: postgresAdminLogin
    administratorLoginPassword: postgresAdminPassword
    storage: { storageSizeGB: 32 }
    backup: { backupRetentionDays: 14, geoRedundantBackup: 'Disabled' }
    highAvailability: { mode: 'Disabled' } // consider 'ZoneRedundant' for production
    network: {
      // Public access shown for simplicity of first deployment. For
      // production, remove this and use a delegated subnet + Private
      // Endpoint instead (see SECURITY_ARCHITECTURE.md).
      publicNetworkAccess: 'Enabled'
    }
  }
}

resource postgresFirewallAzure 'Microsoft.DBforPostgreSQL/flexibleServers/firewallRules@2023-06-01-preview' = {
  parent: postgresServer
  name: 'AllowAzureServices'
  properties: {
    startIpAddress: '0.0.0.0'
    endIpAddress: '0.0.0.0'
  }
}

resource postgresDb 'Microsoft.DBforPostgreSQL/flexibleServers/databases@2023-06-01-preview' = {
  parent: postgresServer
  name: postgresDbName
}

resource appServicePlan 'Microsoft.Web/serverfarms@2023-01-01' = {
  name: planName
  location: location
  sku: {
    name: appServicePlanSku
  }
  kind: 'linux'
  properties: {
    reserved: true
  }
}

resource webApp 'Microsoft.Web/sites@2023-01-01' = {
  name: webAppName
  location: location
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    serverFarmId: appServicePlan.id
    httpsOnly: true
    siteConfig: {
      linuxFxVersion: 'PYTHON|3.12'
      appCommandLine: 'startup.sh'
      minTlsVersion: '1.2'
      ftpsState: 'Disabled'
      alwaysOn: true
      healthCheckPath: '/login'
      appSettings: [
        { name: 'APP_ENV', value: 'production' }
        { name: 'DEV_AUTH_BYPASS', value: 'false' }
        { name: 'ENTRA_TENANT_ID', value: entraTenantId }
        { name: 'ENTRA_CLIENT_ID', value: entraClientId }
        // Secrets below are Key Vault references — populate the vault
        // separately (see azure/README.md), do not put real values here.
        { name: 'SECRET_KEY', value: '@Microsoft.KeyVault(VaultName=${keyVaultName};SecretName=app-secret-key)' }
        { name: 'ENTRA_CLIENT_SECRET', value: '@Microsoft.KeyVault(VaultName=${keyVaultName};SecretName=entra-client-secret)' }
        { name: 'DATABASE_URL', value: '@Microsoft.KeyVault(VaultName=${keyVaultName};SecretName=database-url)' }
        { name: 'MAIL_ENABLED', value: 'true' }
        { name: 'MAIL_SENDER_UPN', value: '@Microsoft.KeyVault(VaultName=${keyVaultName};SecretName=mail-sender-upn)' }
        { name: 'BOOTSTRAP_ADMIN_UPNS', value: '@Microsoft.KeyVault(VaultName=${keyVaultName};SecretName=bootstrap-admin-upns)' }
        { name: 'APPLICATIONINSIGHTS_CONNECTION_STRING', value: appInsights.properties.ConnectionString }
        { name: 'SCM_DO_BUILD_DURING_DEPLOYMENT', value: 'true' }
        { name: 'WEBSITES_PORT', value: '8000' }
      ]
    }
  }
}

// Grant the Web App's managed identity permission to read secrets from Key Vault
resource kvSecretsUserRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(keyVault.id, webApp.id, 'KeyVaultSecretsUser')
  scope: keyVault
  properties: {
    roleDefinitionId: subscriptionResourceId(
      'Microsoft.Authorization/roleDefinitions',
      '4633458b-17de-408a-b874-0445c86b69e6' // Key Vault Secrets User
    )
    principalId: webApp.identity.principalId
    principalType: 'ServicePrincipal'
  }
}

output webAppName string = webApp.name
output webAppDefaultHostname string = webApp.properties.defaultHostName
output keyVaultName string = keyVault.name
output postgresServerFqdn string = postgresServer.properties.fullyQualifiedDomainName
output appInsightsConnectionString string = appInsights.properties.ConnectionString
