import os
from dotenv import load_dotenv

load_dotenv()


def _split_csv(value):
    return [v.strip() for v in (value or "").split(",") if v.strip()]


class Config:
    # ── Core Flask ──────────────────────────────────────────────────────────
    # In Azure, this is injected as an App Service "Application Setting"
    # sourced from a Key Vault reference: @Microsoft.KeyVault(SecretUri=...)
    # Never hard-code a real value here or in .env for anything but local dev.
    SECRET_KEY = os.environ.get("SECRET_KEY")
    if not SECRET_KEY:
        raise RuntimeError(
            "SECRET_KEY is not set. Set it via App Service configuration "
            "(Key Vault reference) or a local .env file for development."
        )

    # ── Database ────────────────────────────────────────────────────────────
    # Production target: Azure Database for PostgreSQL - Flexible Server.
    # DATABASE_URL example:
    #   postgresql+psycopg2://<user>@<server>:<password>@<server>.postgres.database.azure.com:5432/bfc?sslmode=require
    # Falls back to local SQLite ONLY when explicitly running in dev mode,
    # so the app never silently starts against SQLite in Azure.
    DATABASE_URL = os.environ.get("DATABASE_URL")
    APP_ENV = os.environ.get("APP_ENV", "development")  # development | production
    if not DATABASE_URL:
        if APP_ENV == "production":
            raise RuntimeError("DATABASE_URL is required when APP_ENV=production")
        DATABASE_URL = "sqlite:///bfc.db"
    SQLALCHEMY_DATABASE_URI = DATABASE_URL
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        "pool_pre_ping": True,   # avoids stale connections after PaaS DB failover
        "pool_recycle": 280,     # stay under typical idle-connection timeouts
    }

    # ── Session / cookie hardening ──────────────────────────────────────────
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = APP_ENV == "production"
    PREFERRED_URL_SCHEME = "https"
    PERMANENT_SESSION_LIFETIME = int(os.environ.get("SESSION_LIFETIME_SECONDS", 8 * 3600))

    # ── Microsoft Entra ID (Azure AD) — user sign-in (OIDC / MSAL) ──────────
    ENTRA_TENANT_ID     = os.environ.get("ENTRA_TENANT_ID", "")
    ENTRA_CLIENT_ID     = os.environ.get("ENTRA_CLIENT_ID", "")
    ENTRA_CLIENT_SECRET = os.environ.get("ENTRA_CLIENT_SECRET", "")  # Key Vault reference in Azure
    ENTRA_AUTHORITY     = f"https://login.microsoftonline.com/{ENTRA_TENANT_ID}" if ENTRA_TENANT_ID else ""
    # Redirect URI registered on the App Registration, e.g.
    # https://bfc-access-review.azurewebsites.net/auth/callback
    ENTRA_REDIRECT_PATH = "/auth/callback"
    ENTRA_SCOPES        = ["User.Read"]  # delegated scope for sign-in only

    # UPNs auto-provisioned as admin on first successful sign-in. All other
    # first-time sign-ins are rejected until an admin adds their account
    # (Users Management tab) with an owner_key.
    BOOTSTRAP_ADMIN_UPNS = _split_csv(os.environ.get("BOOTSTRAP_ADMIN_UPNS", ""))

    # ── Microsoft Graph — application mail sending (client credentials) ─────
    # Uses the SAME app registration as sign-in, with an additional
    # *application* permission: Mail.Send, admin-consented, and ideally
    # restricted via an Exchange Online "application access policy" to only
    # the mailbox in MAIL_SENDER_UPN (see SECURITY_ARCHITECTURE.md).
    MAIL_SENDER_UPN = os.environ.get("MAIL_SENDER_UPN", "")
    MAIL_ENABLED    = os.environ.get("MAIL_ENABLED", "false").lower() == "true"

    # ── Local development only ───────────────────────────────────────────────
    # Bypasses Entra sign-in with a simple "sign in as this email" form.
    # Must NEVER be enabled outside local dev — enforced in app.py, which
    # refuses to start with this flag on when APP_ENV=production.
    DEV_AUTH_BYPASS = os.environ.get("DEV_AUTH_BYPASS", "false").lower() == "true"

    # ── Application Insights (optional but recommended) ─────────────────────
    APPLICATIONINSIGHTS_CONNECTION_STRING = os.environ.get(
        "APPLICATIONINSIGHTS_CONNECTION_STRING", ""
    )
