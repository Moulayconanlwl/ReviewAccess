"""
Microsoft Entra ID (Azure AD) sign-in for this app, via the OAuth2
Authorization Code flow implemented with MSAL for Python.

This module only handles AUTHENTICATION (proving who the user is).
Authorization (admin vs filter_owner, owner_key) stays in the local
`users` table, keyed by the user's Entra UPN/email — see app.py and
the Users Management admin tab.
"""
import msal
from flask import current_app, session, url_for


def _msal_app():
    cfg = current_app.config
    return msal.ConfidentialClientApplication(
        client_id=cfg["ENTRA_CLIENT_ID"],
        client_credential=cfg["ENTRA_CLIENT_SECRET"],
        authority=cfg["ENTRA_AUTHORITY"],
    )


def build_auth_url(state):
    """Build the URL that starts the Entra ID sign-in redirect."""
    redirect_uri = url_for("auth_callback", _external=True, _scheme="https")
    return _msal_app().get_authorization_request_url(
        scopes=current_app.config["ENTRA_SCOPES"],
        state=state,
        redirect_uri=redirect_uri,
    )


def acquire_token_by_auth_code(code):
    """Exchange the authorization code for tokens and return the result
    dict from MSAL, which includes 'id_token_claims' with the user's
    identity (upn/preferred_username, name, oid) on success, or an
    'error' key on failure.
    """
    redirect_uri = url_for("auth_callback", _external=True, _scheme="https")
    return _msal_app().acquire_token_by_authorization_code(
        code=code,
        scopes=current_app.config["ENTRA_SCOPES"],
        redirect_uri=redirect_uri,
    )


def build_logout_url():
    """Signs the user out of Entra ID too (not just this app's session),
    so a shared-device 'Logout' actually ends the SSO session.
    """
    post_logout = url_for("login_page", _external=True, _scheme="https")
    return (
        f"{current_app.config['ENTRA_AUTHORITY']}/oauth2/v2.0/logout"
        f"?post_logout_redirect_uri={post_logout}"
    )


def extract_identity(token_result):
    """Pull the stable identity fields out of an MSAL token result."""
    claims = token_result.get("id_token_claims", {})
    upn = claims.get("preferred_username") or claims.get("upn") or claims.get("email")
    return {
        "upn": (upn or "").lower().strip(),
        "name": claims.get("name", ""),
        "oid": claims.get("oid", ""),
    }
