"""
Sends mail via the Microsoft Graph API using the app's own client
credentials (application permission Mail.Send, admin-consented).

Recommended hardening (see SECURITY_ARCHITECTURE.md):
- Grant Mail.Send as an *application* permission on the same App
  Registration used for sign-in, with admin consent.
- Restrict which mailbox(es) the app can send as using an Exchange
  Online "ApplicationAccessPolicy" scoped to MAIL_SENDER_UPN, so a
  compromised app secret cannot be used to send as arbitrary users.
"""
import logging

import msal
import requests
from flask import current_app

logger = logging.getLogger(__name__)

GRAPH_SCOPE = ["https://graph.microsoft.com/.default"]


class MailError(Exception):
    pass


def _get_app_token():
    cfg = current_app.config
    app = msal.ConfidentialClientApplication(
        client_id=cfg["ENTRA_CLIENT_ID"],
        client_credential=cfg["ENTRA_CLIENT_SECRET"],
        authority=cfg["ENTRA_AUTHORITY"],
    )
    result = app.acquire_token_for_client(scopes=GRAPH_SCOPE)
    if "access_token" not in result:
        raise MailError(
            f"Failed to acquire Graph app token: "
            f"{result.get('error')}: {result.get('error_description')}"
        )
    return result["access_token"]


def send_mail(to_addresses, subject, html_body):
    """Send an HTML email to one or more recipients via Graph.

    Returns True on success. Raises MailError on failure. No-ops (and
    logs) if MAIL_ENABLED is false, so local/dev/staging environments
    don't need real Graph credentials to run the app.
    """
    cfg = current_app.config
    if not cfg.get("MAIL_ENABLED"):
        logger.info("MAIL_ENABLED=false — skipping email. Subject: %s To: %s", subject, to_addresses)
        return False

    sender = cfg.get("MAIL_SENDER_UPN")
    if not sender:
        raise MailError("MAIL_SENDER_UPN is not configured")

    if isinstance(to_addresses, str):
        to_addresses = [to_addresses]
    to_addresses = [a for a in to_addresses if a]
    if not to_addresses:
        raise MailError("No recipient address provided")

    token = _get_app_token()
    payload = {
        "message": {
            "subject": subject,
            "body": {"contentType": "HTML", "content": html_body},
            "toRecipients": [{"emailAddress": {"address": a}} for a in to_addresses],
        },
        "saveToSentItems": "true",
    }

    resp = requests.post(
        f"https://graph.microsoft.com/v1.0/users/{sender}/sendMail",
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        json=payload,
        timeout=15,
    )
    if resp.status_code >= 300:
        raise MailError(f"Graph sendMail failed ({resp.status_code}): {resp.text}")
    return True


def reminder_email_body(owner_key, deadline, pct):
    deadline_txt = deadline or "the deadline set by the admin"
    return f"""
    <div style="font-family:Segoe UI,sans-serif;font-size:14px;color:#0f172a;">
      <p>Hello,</p>
      <p>This is a reminder that your BFC Access Review (owner key <b>{owner_key}</b>)
      is currently <b>{pct}% complete</b> and must be finished before
      <b>{deadline_txt}</b>.</p>
      <p>Please log in to the review portal to validate or deactivate the
      remaining users assigned to you.</p>
      <p>Thank you,<br>BFC Access Review — Automated Reminder</p>
    </div>
    """
