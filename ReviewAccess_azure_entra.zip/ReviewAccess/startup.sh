#!/bin/bash
# Startup command for Azure App Service (Linux, Python).
# Set this as the App Service "Startup Command" (Configuration > General settings),
# or reference it via `startup.sh` in the deployment package root.
gunicorn --workers 4 --threads 2 --timeout 120 --bind 0.0.0.0:8000 app:app
