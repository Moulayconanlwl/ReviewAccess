from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime

db = SQLAlchemy()

class User(UserMixin, db.Model):
    __tablename__ = "users"
    id            = db.Column(db.Integer, primary_key=True)
    email         = db.Column(db.String(200), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    role          = db.Column(db.String(20), default="filter_owner")  # 'admin' or 'filter_owner'
    owner_key     = db.Column(db.String(200), nullable=True)
    created_at    = db.Column(db.DateTime, default=datetime.utcnow)

class ReviewSession(db.Model):
    __tablename__ = "review_sessions"
    id          = db.Column(db.String(32), primary_key=True)
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)
    deadline    = db.Column(db.String(20))
    quarter     = db.Column(db.String(20))
    created_by  = db.Column(db.String(200))
    rows        = db.relationship("UserRow", backref="session", lazy=True, cascade="all, delete-orphan")

class UserRow(db.Model):
    __tablename__ = "user_rows"
    id                 = db.Column(db.Integer, primary_key=True)
    session_id         = db.Column(db.String(32), db.ForeignKey("review_sessions.id"))
    code               = db.Column(db.String(50))
    user_name          = db.Column(db.String(200))
    functional_profile = db.Column(db.String(100))
    data_entry_access  = db.Column(db.String(200))
    manager            = db.Column(db.String(200))
    departement        = db.Column(db.String(200))
    location           = db.Column(db.String(100))
    filter_owner       = db.Column(db.String(200), index=True)
    active_bfc         = db.Column(db.String(10))
    active_ad          = db.Column(db.String(10))
    bfc_reporting_unit = db.Column(db.String(200), nullable=True)
    entity_name        = db.Column(db.String(200), nullable=True)
    access_right       = db.Column(db.String(10), nullable=True)
    extra_data         = db.Column(db.JSON)
    choice             = db.Column(db.String(20), default="pending")
    validator          = db.Column(db.String(200))
    validated_at       = db.Column(db.DateTime, nullable=True)
    signoff_at         = db.Column(db.DateTime, nullable=True)

    # Snapshot of editable-field values as originally uploaded, e.g.
    # {"functional_profile": "...", "bfc_reporting_unit": "...", ...}
    # Used to detect whether a filter owner modified a row from its
    # original imported value.
    original_values    = db.Column(db.JSON, nullable=True)
    last_edited_by      = db.Column(db.String(200), nullable=True)
    last_edited_at       = db.Column(db.DateTime, nullable=True)

    def is_modified(self, editable_fields):
        """True if any current editable field value differs from the
        value originally imported for this row."""
        if not self.original_values:
            return False
        for field in editable_fields:
            original = self.original_values.get(field)
            current = getattr(self, field)
            if (current or None) != (original or None):
                return True
        return False

class Delegation(db.Model):
    __tablename__ = "delegations"
    id           = db.Column(db.Integer, primary_key=True)
    session_id   = db.Column(db.String(32), db.ForeignKey("review_sessions.id"))
    owner_key    = db.Column(db.String(200))
    delegate_key = db.Column(db.String(200))
    # List of "data_entry_access" values the delegate is scoped to see,
    # e.g. ["Read Only - Region A"]. The delegate only sees rows from
    # owner_key whose data_entry_access is in this list.
    data_entry_access_scope = db.Column(db.JSON, nullable=True)